<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    //to login page
public function loginPage(){
    return view('login');

}

    public function store(Request $request)
    {
        //
        // dd($request->all());
            $formFields = $request->validate([
                'name' => ['required', 'min:3'],
                'email' => ['required', Rule::unique('users', 'email')],
                'password' => ['required', 'confirmed', 'min:6'],
                'role' => 'required',
                'number' => 'required',

            ]);

            if ($request->hasFile('image')) {
                $formFields['image'] = $request->file('image')->store('images', 'public');
            }
            // Hash password
            $formFields['password'] = bcrypt($formFields['password']);

            // Insert user into the 'users' table
            DB::table('users')->insert($formFields);

            // Authenticate the user
            return redirect('/adminProfilePage')->with('success', 'Admin is added successfully !');


    }

    public function editingAdminProfile(request $request,$id){
    // dd($request['name']);
    $user= User::find($id);
    // dd($user->id);
        $admin = Auth::user(); // Assuming you're using Laravel's built-in authentication
    if($admin->id !== $user->id){
    return redirect('/login');
    }
     $addAdmin = $request->validate([
        'name'=>'string',
        'email'=>'email|string',
        'number'=>'string'
    ]);
    if($request->hasFile('image')){
        $addAdmin['image']=$request->file('image')->store('images','public');
    }
    // $user->update($addAdmin);
    DB::table('users')->where('id', $user->id)->update($addAdmin);

    return redirect('/adminProfilePage')->with('success','Admin is Updated successfully');

    }

    public function authenticate(Request $request)
    {

        $formFields = $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        // Attempt to authenticate the user
        if (auth()->attempt($formFields)) {
            $request->session()->regenerate();
            // $cookie = request()->cookie('laravel_session');

            $sessionId = session();
            // dd($sessionId);
            //  dd($cookie);
            return redirect('/')->with('success', 'Logged in successfully!');
        }

        return back()->withErrors(['email' => 'Invalid credentials'])->onlyInput('email');
    }

    // logout
    public function logout(Request $request)
    {
        Auth()->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login')->with('message', 'logged out successfully !');
    }
}
