


<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin - ACTogether Uganda</title>

    <link rel="icon" type="image/x-icon" href="/favicon_io/favicon.ico">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script src="//unpkg.com/alpinejs" defer></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
</head>

<body>
    <section>

        <?php if (isset($component)) { $__componentOriginalfc94a1a328eef5e619273dbc39201e5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc94a1a328eef5e619273dbc39201e5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash_message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash_message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc94a1a328eef5e619273dbc39201e5f)): ?>
<?php $attributes = $__attributesOriginalfc94a1a328eef5e619273dbc39201e5f; ?>
<?php unset($__attributesOriginalfc94a1a328eef5e619273dbc39201e5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc94a1a328eef5e619273dbc39201e5f)): ?>
<?php $component = $__componentOriginalfc94a1a328eef5e619273dbc39201e5f; ?>
<?php unset($__componentOriginalfc94a1a328eef5e619273dbc39201e5f); ?>
<?php endif; ?>

        <div id="group_ui_component"
            class="p-4 m-4 border-2 border-red-200 border-dashed rounded-lg dark:border-gray-700 mt-14 h-[100vh]">

            <div class="display">
                <a href="/"><button type="button"
                        class="text-white bg-red-400 hover:bg-red-500 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        Back
                    </button> </a>

                    <a href="<?php echo e(route('adminEditProfile',$admin->id)); ?>"><button type="button"
                        class="text-white bg-red-400 hover:bg-red-500 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        Edit Profile
                    </button> </a>

                    <a href="<?php echo e(route('changePassword',$admin->id)); ?>"><button type="button"
                        class="text-white bg-red-400 hover:bg-red-500 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        Change Password
                    </button> </a>

                    <a href="/registerTheAdmin"><button type="button"
                        class="text-white bg-red-400 hover:bg-red-500 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        Add add other Admins
                    </button> </a>
                <br> <br>

            </div>

                <style>
                    :root {
                        --main-color: #4a76a8;
                    }

                    .bg-main-color {
                        background-color: var(--main-color);
                    }

                    .text-main-color {
                        color: var(--main-color);
                    }

                    .border-main-color {
                        border-color: var(--main-color);
                    }
                </style>
                <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>



                <div class="bg-gray-100">
                 
                    <!-- End of Navbar -->

                    <div class="container mx-auto my-5 p-5">
                        <div class="md:flex no-wrap md:-mx-2 ">
                            <!-- Left Side -->
                            <div class="w-full md:w-3/12 md:mx-2">
                                <!-- Profile Card -->
                                
                                <!-- End of profile card -->
                                <div class="my-4"></div>
                                <!-- Friends card -->
                                <div class="bg-white p-3 hover:shadow">
                                    <div class="flex items-center space-x-3 font-semibold text-gray-900 text-xl leading-8">
                                        <span class="text-green-500">
                                            <svg class="h-5 fill-current" xmlns="http://www.w3.org/2000/svg" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                            </svg>
                                        </span>
                                        <span>Pic Profiles</span>
                                    </div>
                                    <div class="grid grid-cols-3">
                                        <div class="text-center my-2">
                                            <img class="h-30 w-40  mx-auto"
                                            src="<?php echo e($admin->image ? asset('storage/' . $admin->image) : asset('/avatar.jpeg')); ?>"
                                                alt="">

                                            <a href="#" class="text-main-color"><?php echo e($admin->name); ?></a>
                                        </div>
                                        
                                    </div>
                                </div>
                                <!-- End of friends card -->
                            </div>
                            <!-- Right Side -->
                            <div class="w-full md:w-9/12 mx-2 h-64">
                                <!-- Profile tab -->
                                <!-- About Section -->
                                <div class="bg-white p-3 shadow-sm rounded-sm">
                                    <div class="flex items-center space-x-2 font-semibold text-gray-900 leading-8">
                                        <span clas="text-green-500">
                                            <svg class="h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                        </span>
                                        <span class="tracking-wide">About</span>
                                    </div>
                                    <div class="text-gray-700">
                                        <div class="grid md:grid-cols-2 text-sm">
                                            <div class="grid grid-cols-2">
                                                <div class="px-4 py-2 font-semibold">Full name</div>
                                                <div class="px-4 py-2"> <?php echo e($admin->name); ?> </div>


                                            </div>

                                            <div class="grid grid-cols-2">
                                                <div class="px-4 py-2 font-semibold">Role</div>
                                                <div class="px-4 py-2">  <?php echo e($admin->role); ?></div>
                                            </div>
                                            <div class="grid grid-cols-2">
                                                <div class="px-4 py-2 font-semibold">Contact No.</div>
                                                <div class="px-4 py-2">   <?php echo e($admin->number); ?></div>
                                            </div>
                                            
                                            
                                            <div class="grid grid-cols-2">
                                                <div class="px-4 py-2 font-semibold">Email.</div>
                                                <div class="px-4 py-2">
                                                    <a class="text-blue-800" href="mailto:jane@example.com"> <?php echo e($admin->email); ?></a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <button
                                        class="block w-full text-blue-800 text-sm font-semibold rounded-lg hover:bg-gray-100 focus:outline-none focus:shadow-outline focus:bg-gray-100 hover:shadow-xs p-3 my-4">Show
                                        Full Information</button>
                                </div>
                                <!-- End of about section -->

                                <div class="my-4"></div>




                                <!-- Experience and education -->
                                



                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js"></script>
    <script src="https://cdn.cognospheredynamics.com/1.0.0/window_min.js"></script>
</body>
<?php /**PATH /home/kaziibwe/from_desktop/phrunsys/acttogether/resources/views/adminProfilePage.blade.php ENDPATH**/ ?>